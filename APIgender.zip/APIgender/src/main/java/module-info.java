module com.example.apigender {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.apigender to javafx.fxml;
    exports com.example.apigender;
}