package com.example.apigender;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import java.io.IOException;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {
        Button btn = new Button();
        btn.setText("Fetch Data from API");
        btn.setOnAction(event -> {
            try {
                String urlString = "https://api.genderize.io/?name=scott";
                String jsonResponse = APIUtility.callAPI(urlString);


                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("API Response");
                alert.setHeaderText(null);
                alert.setContentText(jsonResponse);
                alert.showAndWait();
            } catch (IOException e) {
                e.printStackTrace();

                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText(null);
                alert.setContentText("Failed to fetch data from API.");
                alert.showAndWait();
            }
        });

        StackPane root = new StackPane();
        root.getChildren().add(btn);

        Scene scene = new Scene(root, 300, 250);

        primaryStage.setTitle("API Gender App");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
